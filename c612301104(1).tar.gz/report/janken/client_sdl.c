#define _POSIX_C_SOURCE 200112L
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <errno.h>

#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include "janken.h"

#define WIN_W 480
#define WIN_H 240

typedef enum { S_IDLE, S_WAIT, S_SHOW, S_EXIT } State;

typedef struct {
    SDL_Rect rect;
    const char* label;
    int val; // for GU/CH/PA or -1 for quit
} Button;

static int set_nonblock(int fd){
    int fl = fcntl(fd, F_GETFL, 0);
    if (fl<0) return -1;
    return fcntl(fd, F_SETFL, fl|O_NONBLOCK);
}

static void draw_text(SDL_Renderer*r, TTF_Font*font, const char*txt, int cx, int cy){
    SDL_Color col={255,255,255,255};
    SDL_Surface* surf = TTF_RenderUTF8_Blended(font, txt, col);
    SDL_Texture* tex = SDL_CreateTextureFromSurface(r, surf);
    int w=0,h=0; SDL_QueryTexture(tex,NULL,NULL,&w,&h);
    SDL_Rect dst = {cx - w/2, cy - h/2, w, h};
    SDL_RenderCopy(r, tex, NULL, &dst);
    SDL_DestroyTexture(tex); SDL_FreeSurface(surf);
}

int main(int argc, char**argv){
    const char* server_ip = (argc>=2)? argv[1] : "127.0.0.1";
    int server_port = (argc>=3)? atoi(argv[2]) : 50000;

    // connect
    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock<0){perror("socket"); return 1;}
    struct sockaddr_in sa={0};
    sa.sin_family=AF_INET; sa.sin_port=htons(server_port);
    if (inet_pton(AF_INET, server_ip, &sa.sin_addr)<=0){perror("inet_pton"); return 1;}
    if (connect(sock,(struct sockaddr*)&sa,sizeof(sa))<0){perror("connect"); return 1;}
    set_nonblock(sock);

    if (SDL_Init(SDL_INIT_VIDEO|SDL_INIT_TIMER)!=0){fprintf(stderr,"SDL: %s\n",SDL_GetError()); return 1;}
    if (TTF_Init()!=0){fprintf(stderr,"TTF: %s\n",TTF_GetError()); return 1;}

    
    TTF_Font* font = TTF_OpenFont("/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc", 28);
    if (!font){fprintf(stderr,"Font open failed: %s\n",TTF_GetError()); return 1;}

    SDL_Window* win = SDL_CreateWindow("じゃんけんクライアント", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, WIN_W, WIN_H, 0);
    SDL_Renderer* ren = SDL_CreateRenderer(win, -1, SDL_RENDERER_ACCELERATED|SDL_RENDERER_PRESENTVSYNC);

    Button btns[4] = {
        {.rect={30,150,100,60}, .label="グー",   .val=HAND_GU},
        {.rect={140,150,100,60},.label="チョキ", .val=HAND_CHO},
        {.rect={250,150,100,60},.label="パー",   .val=HAND_PA},
        {.rect={360,150,100,60},.label="終わる", .val=-1},
    };

    State st = S_IDLE;
    int last_result = -1; // RES_*
    bool running = true;

    while (running){
        // --- ネット受信（ノンブロッキング） ---
        Msg m; ssize_t n = recv(sock,&m,sizeof(m),0);
        if (n==sizeof(m)){
            if (m.type==MSG_RESULT){
                last_result = m.val;
                st = S_SHOW; // 結果表示→再び押せるようになる
            } else if (m.type==MSG_END){
                st = S_EXIT;
                running = false;
            }
        }

        // --- イベント処理 ---
        SDL_Event ev;
        while (SDL_PollEvent(&ev)){
            if (ev.type==SDL_QUIT){ running=false; break; }
            if (ev.type==SDL_MOUSEBUTTONDOWN && ev.button.button==SDL_BUTTON_LEFT){
                int mx = ev.button.x, my = ev.button.y;
                for (int i=0;i<4;i++){
                    SDL_Rect r = btns[i].rect;
                    if (mx>=r.x && mx<r.x+r.w && my>=r.y && my<r.y+r.h){
                        if (btns[i].val==-1){
                            // quit
                            Msg q={.type=MSG_QUIT,.val=0};
                            send(sock,&q,sizeof(q),0);
                            running=false;
                        }else{
                            if (st==S_IDLE || st==S_SHOW){
                                Msg c={.type=MSG_CHOICE,.val=(uint8_t)btns[i].val};
                                send(sock,&c,sizeof(c),0);
                                st = S_WAIT; // 結果待ち→ボタン無効
                            }
                        }
                    }
                }
            }
        }

        // --- 描画 ---
        SDL_SetRenderDrawColor(ren, 30, 30, 40, 255);
        SDL_RenderClear(ren);

        // タイトル
        draw_text(ren, font, "じゃんけん：相手の手を待っています", WIN_W/2, 30);

        // 状態メッセージ
        const char* msg = NULL;
        if (st==S_IDLE) msg="手を選んでください";
        else if (st==S_WAIT) msg="相手を待っています…（ボタン無効）";
        else if (st==S_SHOW){
            if (last_result==RES_WIN) msg="あなたの勝ち！";
            else if (last_result==RES_DRAW) msg="あいこです";
            else if (last_result==RES_LOSE) msg="あなたの負け…";
            else msg="結果を受信しました";
        } else msg="終了します";
        draw_text(ren, font, msg, WIN_W/2, 80);

        // ボタン表示（WAIT中は半透明＆無効）
        for (int i=0;i<4;i++){
            SDL_Rect r = btns[i].rect;
            bool disabled = (st==S_WAIT) && (btns[i].val!=-1);
            Uint8 alpha = disabled ? 80 : 200;
            SDL_SetRenderDrawColor(ren, 70, 110, 190, alpha);
            SDL_RenderFillRect(ren, &r);
            SDL_SetRenderDrawColor(ren, 240, 240, 240, 220);
            SDL_RenderDrawRect(ren, &r);
            draw_text(ren, font, btns[i].label, r.x + r.w/2, r.y + r.h/2);
        }

        SDL_RenderPresent(ren);
    }

    TTF_CloseFont(font);
    SDL_DestroyRenderer(ren);
    SDL_DestroyWindow(win);
    TTF_Quit();
    SDL_Quit();
    close(sock);
    return 0;
}
