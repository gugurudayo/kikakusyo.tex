#ifndef JANKEN_PROTO_H
#define JANKEN_PROTO_H
#include <stdint.h>

enum { MSG_CHOICE=1, MSG_QUIT=2, MSG_RESULT=3, MSG_END=4 };
enum { HAND_GU=0, HAND_CHO=1, HAND_PA=2 };
enum { RES_LOSE=0, RES_DRAW=1, RES_WIN=2 };

typedef struct __attribute__((packed)) {
    uint8_t type;
    uint8_t val;
} Msg;

#endif
