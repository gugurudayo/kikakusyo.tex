#define _POSIX_C_SOURCE 200112L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/select.h>
#include <errno.h>
#include "janken.h"

#define LISTEN_PORT 50000
#define BACKLOG 2

static int decide(int a, int b) {
    // 0=gu,1=cho,2=pa
    if (a==b) return 0; // draw
    // (a - b + 3) % 3 == 1 → aが勝ち（じゃんけんの性質）
    int d = (a - b + 3) % 3;
    return (d==1) ? 1 : -1; // 1=a win, -1=b win
}

int main(void){
    int lsock = socket(AF_INET, SOCK_STREAM, 0);
    if (lsock<0){perror("socket"); return 1;}

    int yes=1; setsockopt(lsock,SOL_SOCKET,SO_REUSEADDR,&yes,sizeof(yes));

    struct sockaddr_in addr={0};
    addr.sin_family=AF_INET;
    addr.sin_addr.s_addr=htonl(INADDR_ANY);
    addr.sin_port=htons(LISTEN_PORT);
    if (bind(lsock,(struct sockaddr*)&addr,sizeof(addr))<0){perror("bind"); return 1;}
    if (listen(lsock,BACKLOG)<0){perror("listen"); return 1;}
    printf("Server listening on %d\n", LISTEN_PORT);

    int cs[2]={-1,-1};
    int choices[2]={-1,-1};

    fd_set rfds;
    int maxfd = lsock;

    while (1){
        FD_ZERO(&rfds);
        FD_SET(lsock,&rfds);
        for(int i=0;i<2;i++) if(cs[i]!=-1) FD_SET(cs[i],&rfds);
        int r = select(maxfd+1,&rfds,NULL,NULL,NULL);
        if (r<0){ if(errno==EINTR) continue; perror("select"); break; }

        if (FD_ISSET(lsock,&rfds)){
            // accept until we have 2
            struct sockaddr_in ca; socklen_t calen=sizeof(ca);
            int ns = accept(lsock,(struct sockaddr*)&ca,&calen);
            if (ns<0){perror("accept"); continue;}
            char ip[64]; inet_ntop(AF_INET,&ca.sin_addr,ip,sizeof(ip));
            printf("Client from %s\n",ip);
            int placed=0;
            for(int i=0;i<2;i++) if(cs[i]==-1){ cs[i]=ns; placed=1; break; }
            if(!placed){ close(ns); } // already full
            if (ns>maxfd) maxfd=ns;
        }

        for(int i=0;i<2;i++){
            if (cs[i]==-1) continue;
            if (!FD_ISSET(cs[i],&rfds)) continue;

            Msg m; ssize_t n = recv(cs[i], &m, sizeof(m), 0);
            if (n==0){
                // disconnect → 終了処理
                Msg end={.type=MSG_END,.val=0};
                for(int k=0;k<2;k++) if(cs[k]!=-1) send(cs[k],&end,sizeof(end),0);
                goto cleanup;
            }
            if (n<0){perror("recv"); goto cleanup;}
            if (n!=sizeof(m)) continue;

            if (m.type==MSG_QUIT){
                Msg end={.type=MSG_END,.val=0};
                for(int k=0;k<2;k++) if(cs[k]!=-1) send(cs[k],&end,sizeof(end),0);
                goto cleanup;
            } else if (m.type==MSG_CHOICE){
                choices[i]=m.val;
                // 両者の手が出揃ったら判定
                if (choices[0]!=-1 && choices[1]!=-1 && cs[0]!=-1 && cs[1]!=-1){
                    int res = decide(choices[0], choices[1]);
                    Msg r0={.type=MSG_RESULT,.val = (res==1)?RES_WIN:(res==0)?RES_DRAW:RES_LOSE};
                    Msg r1={.type=MSG_RESULT,.val = (res==-1)?RES_WIN:(res==0)?RES_DRAW:RES_LOSE};
                    send(cs[0],&r0,sizeof(r0),0);
                    send(cs[1],&r1,sizeof(r1),0);
                    choices[0]=choices[1]=-1;
                }
            }
        }
    }

cleanup:
    for(int i=0;i<2;i++) if(cs[i]!=-1) close(cs[i]);
    close(lsock);
    puts("Server exit");
    return 0;
}
