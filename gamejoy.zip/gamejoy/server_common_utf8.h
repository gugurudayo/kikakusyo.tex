/*server_common_utf8.h*/

#ifndef _SERVER_COMMON_H_
#define _SERVER_COMMON_H_

#include"common_utf8.h"

#define ALL_CLIENTS	-1  

#endif
